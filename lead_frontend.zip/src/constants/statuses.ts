export const statusesRowVariants = [
  {
    label: 'Активен',
    value: 'active',
  },
  {
    label: 'Неактивен',
    value: 'inactive',
  },
  {
    label: 'Ошибка',
    value: 'error',
  },
];
