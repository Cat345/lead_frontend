import { Title } from '@mantine/core';

export const SubscribePage = () => {
  return (
    <div>
      <Title>Купить</Title>
    </div>
  );
};
