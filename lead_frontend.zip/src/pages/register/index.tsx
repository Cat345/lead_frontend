import { Logo } from '../../shared/ui/Logo';
import { RegisterPage } from './RegisterPage';

export const Register = () => {
  return <RegisterPage title={<Logo />} />;
};
