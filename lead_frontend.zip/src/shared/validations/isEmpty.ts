export const isEmpty = (string: string) => (!string ? true : string.trim().length === 0);
