export const isEmailValid = (email: string) => /^[^@]+@[^@]+\.[^@]+$/.test(email);
