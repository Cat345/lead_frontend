export const isIncludesSpaces = (string: string) => string.includes(' ');
