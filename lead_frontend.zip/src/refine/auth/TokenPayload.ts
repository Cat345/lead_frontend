export type TokenPayload = { sub: number; email: string; role: 'admin' | 'user'; iat: number };
